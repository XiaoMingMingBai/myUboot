/*
 * Copyright (c) 2015-2017, Renesas Electronics Corporation. All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef PFC_INIT_M3N_H
#define PFC_INIT_M3N_H

void pfc_init_m3n(void);

#endif /* PFC_INIT_M3N_H */
