/*
 * Copyright (c) 2015-2017, Renesas Electronics Corporation
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef PFC_INIT_V3M_H
#define PFC_INIT_V3M_H

void pfc_init_v3m(void);

#endif	/* PFC_INIT_V3M_H */
