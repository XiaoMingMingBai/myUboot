/*
 * Copyright (c) 2017-2018, STMicroelectronics - All Rights Reserved
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef STM32MP1_DDR_HELPERS_H
#define STM32MP1_DDR_HELPERS_H

void ddr_enable_clock(void);

#endif /* STM32MP1_DDR_HELPERS_H */
